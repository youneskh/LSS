No configuration required.
