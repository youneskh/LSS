# Copyright (C) 2010 Savoir-faire Linux (<http://www.savoirfairelinux.com>).
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).

{
    "name": "Management System - Review",
    "version": "19.0.1.1.0",
    "author": "Savoir-faire Linux, Odoo Community Association (OCA)",
    "website": "https://github.com/OCA/management-system",
    "license": "AGPL-3",
    "category": "Management Systems",
    "depends": ["mgmtsystem_kpi", "mgmtsystem_nonconformity"],
    "data": [
        "security/ir.model.access.csv",
        "security/mgmtsystem_review_security.xml",
        "data/ir_sequence.xml",
        "views/mgmtsystem_review.xml",
        "views/kpi_history.xml",
        "views/res_users.xml",
        "report/review.xml",
        "report/report.xml",
    ],
    "demo": [
        "demo/mgmtsystem_review.xml",
    ],
}
